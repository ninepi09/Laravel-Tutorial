<?php
return [
    'image' => [
        'directory' => 'img',
        'thumbnail' => [
            'width' => 250,
            'height' => 170
        ]
    ],
    'default_category_id' => 8,
];
