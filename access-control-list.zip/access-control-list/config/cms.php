<?php
return [
    'image' => [
        'directory' => 'img',
        'thumbnail' => [
            'width' => 250,
            'height' => 170
        ]
    ],
    'default_category_id' => 8,
    'default_user_id' => 1,
];
